# Klangtherapie Crew App — V0.1

UI-Prototyp für eine interne Techno-Kollektiv-PWA.

## Enthalten
- Responsive Desktop/Mobile Layout
- Glassmorphism Design
- Dashboard
- WhatsApp-artige Chatübersicht
- Globales Crew-Kanban
- Admin Benutzerverwaltung
- vorbereitete Bereiche für Kalender, Crew und Dateien
- Demo-Daten, noch ohne Backend

## Start
```bash
npm install
npm run dev
```

Danach die lokale Vite-Adresse im Browser öffnen.

## Nächste Ausbaustufe
1. Supabase Projekt verbinden
2. Auth + Einladungen
3. Profiles / Teams / Rollen / Rechte
4. Realtime Chat + private Nachrichten
5. Aufgaben in PostgreSQL
6. Storage für Anhänge
7. RLS Policies
8. PWA Manifest + Service Worker

## Hinweis
`src/data/demo.ts` enthält aktuell die Demo-Daten.
